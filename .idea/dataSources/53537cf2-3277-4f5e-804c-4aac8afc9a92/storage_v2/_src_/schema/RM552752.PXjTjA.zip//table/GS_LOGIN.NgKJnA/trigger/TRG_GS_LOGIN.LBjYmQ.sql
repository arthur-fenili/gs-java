create trigger TRG_GS_LOGIN
    before insert
    on GS_LOGIN
    for each row
    when (NEW.cod_login IS NULL)
BEGIN
    SELECT seq_gs_login.NEXTVAL
    INTO :NEW.cod_login
    FROM dual;
END;
/

